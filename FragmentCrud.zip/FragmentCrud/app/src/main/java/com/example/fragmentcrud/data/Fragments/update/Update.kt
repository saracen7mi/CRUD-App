package com.example.fragmentcrud.data.Fragments.update

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.text.TextUtils
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.ListFragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.NavArgs
import androidx.navigation.fragment.NavHostFragment

import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.room.Update
import com.example.fragmentcrud.R


import com.example.fragmentcrud.data.Fragments.model.User
import com.example.fragmentcrud.data.Fragments.viewmodel.UserViewModel
import kotlinx.android.synthetic.main.fragment_update.*
import kotlinx.android.synthetic.main.fragment_update.view.*
import kotlinx.android.synthetic.main.fragment_update.view.update_name_editText
import kotlinx.android.synthetic.main.fragment_update.view.update_surname_editText


class Update : Fragment() {

    private val args:UpdateArgs by navArgs()

    private lateinit var userViewModel: UserViewModel
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_update, container, false)


        userViewModel = ViewModelProvider(this).get(UserViewModel::class.java)

        view.update_name_editText.setText(args.curentuser.name.toString())
        view.update_surname_editText.setText(args.curentuser.surname.toString())

        view.updateBotom.setOnClickListener {
            UpdateItem()
        }


        return view
    }

    private fun UpdateItem() {
        val name = update_name_editText.text.toString()
        val surname = update_surname_editText.text.toString()

        if (inputChack(name, surname)) {
            val updateUser = User(args.curentuser.id, name, surname)
            userViewModel

        }
findNavController().navigate(R.id.action_addFragment_to_listFragment)
    }

    fun inputChack(name: String, suranme: String): Boolean {
        return !(TextUtils.isEmpty(name) && TextUtils.isEmpty(suranme))

    }
}

