package com.example.fragmentcrud.data.Fragments.List


import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.findNavController

import androidx.recyclerview.widget.RecyclerView
import com.example.fragmentcrud.R
import com.example.fragmentcrud.data.Fragments.model.User
import com.example.fragmentcrud.data.Fragments.update.UpdateDirections
import kotlinx.android.synthetic.main.adapter_layout.view.*

class UserAdapter() : RecyclerView.Adapter<UserAdapter.ViewHolder>() {
    var userList = emptyList<User>()

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var name = view.name_text_View
        var surname = view.surname_text_View
        val id = view.id_text_View
    }

    override fun getItemCount(): Int {
        return userList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val curentList = userList[position]
        holder.name.text = curentList.name
        holder.surname.text = curentList.surname
        holder.id.text = curentList.id.toString()

        holder.itemView.rowLeyout.setOnClickListener {
            val action=ListFragmentDirections.actionListFragmentToUpdate(curentList)
            holder.itemView.findNavController().navigate(action)
        }
    }

    fun setData(user: List<User>) {
        this.userList = user
notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view =
            LayoutInflater.from(parent.context).inflate(R.layout.adapter_layout, parent, false)
        return ViewHolder(view)
    }
}