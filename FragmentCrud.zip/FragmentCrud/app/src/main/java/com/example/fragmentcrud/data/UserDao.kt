package com.example.fragmentcrud.data

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.fragmentcrud.data.Fragments.model.User

@Dao
interface UserDao {
    @Insert
 suspend   fun addUser(user: User)
    @Delete
 suspend   fun delete(user: User)
    @Query("SELECT * FROM user_table ORDER BY id ASC")
    fun getAll():LiveData<List<User>>
    @Update
  suspend  fun update(user: User)

}